package zz.service;

import zz.model.TodoList;
import zz.model.TodoItem;

import java.awt.event.ActionListener;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.util.Scanner;

public class TodoListService {

    // in memory model

    private TodoList todoList;

    //services

    public void add(TodoItem item){
        todoList.getItems().add(item);
    }

    public void delete(TodoItem item){
        todoList.getItems().remove(item);
    }

    public void set(int index, TodoItem otherItem){
        todoList.getItems().set(index, otherItem);
    }

    public TodoList get() {
        if (todoList == null) {
            todoList = new TodoList();
            todoList.setTitle("My Todo List");
            todoList.getItems().add(new TodoItem("Git"));
            todoList.getItems().add(new TodoItem("swift"));
            todoList.getItems().add(new TodoItem("react"));
        }
        return todoList;
    }

    public TodoList getFromFile(){
        if (todoList == null) {
            Scanner fileIn = null;
            try {
                fileIn = new Scanner(new FileInputStream("MyTodoList.txt"));
            } catch (FileNotFoundException e) {
                System.out.println("Can not found this file.");
                System.exit(0);
            }
            todoList = new TodoList();
            todoList.setTitle("My Todo List");
            while (fileIn.hasNextLine()) {
                todoList.getItems().add(new TodoItem(fileIn.nextLine()));
            }
            fileIn.close();
        }
        return todoList;
    }

    public void save(){
        PrintWriter printWriter = null;
        try {
            printWriter = new PrintWriter(new FileOutputStream("MyTodoList.txt"));
        }catch (FileNotFoundException e){
            System.out.println("Can not create this file.");
            System.exit(0);
        }
        for(TodoItem item : todoList.getItems()){
            printWriter.println(item.getText());
        }
        printWriter.close();
    }
}
