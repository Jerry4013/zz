package zz.ui;

import com.zzpublic.zwing.Button;
import com.zzpublic.zwing.Label;
import com.zzpublic.zwing.TextField;
import com.zzpublic.zwing.View;
import zz.model.TodoItem;
import zz.model.TodoList;
import zz.service.TodoListService;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.LinkedList;

public class MainView extends View{

    private LinkedList<TodoItem> items;

    class AddingListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            if(textField.getText().equals(""))
                JOptionPane.showMessageDialog(null,"Can not add an empty item.",
                        "Wrong",  JOptionPane.ERROR_MESSAGE);
            else{
                TodoItem todoItem = new TodoItem(textField.getText());
                todoListService.add(todoItem);
                textField.setText("");
                dataToView();
            }
        }
    }

    // mark - service

    private TodoListService todoListService = new TodoListService();

    private static final int paddingNormal = 10;
    private static final int paddingSmall = 5;
    private static final int cellHeight = 30;
    private static final int panelHeight = 40;

    private static final int windowPadding = 40;

    private Label titleLabel;
    private Button addButton;
    private TextField textField;
    private View containerView;
    private JTextField textField1;
    private JFrame editWindow;


    protected void initSubviews(){
        super.initSubviews();

        titleLabel = new Label();
        titleLabel.setLocation(paddingNormal, paddingNormal);
        titleLabel.setSize(this.getWidth() - 2 * paddingNormal, cellHeight);
        titleLabel.setText("");
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        this.add(titleLabel);

        View inputView = new View();
        inputView.setSize(this.getWidth(), panelHeight);
        inputView.setLocation(0, this.getHeight() - inputView.getHeight() - windowPadding);
        this.add(inputView);

        addButton = new Button("Add");
        addButton.setSize(100,cellHeight);
        addButton.setLocation(inputView.getWidth() - paddingSmall - addButton.getWidth(), paddingSmall);
        inputView.add(addButton);

        textField = new TextField();
        textField.setSize(addButton.getX() - 2 * paddingSmall, cellHeight);
        textField.setLocation(paddingSmall, paddingSmall);
        inputView.add(textField);
    }

    @Override
    protected void initEvents() {
        super.initEvents();
        AddingListener addingListener = new AddingListener();
        addButton.addActionListener(addingListener);
        textField.addActionListener(addingListener);
    }

    @Override
    protected void viewDidDisplay() {
        super.viewDidDisplay();
        dataToView();
    }

    private void dataToView(){
        TodoList todoList = todoListService.getFromFile();
        titleLabel.setText(todoList.getTitle());

        if (containerView != null){
            this.remove(containerView);
        }
        containerView = new View();
        containerView.setLocation(0, titleLabel.getY() + titleLabel.getHeight() + paddingNormal);
        containerView.setSize(this.getWidth(),
                this.getHeight() - windowPadding - containerView.getY() - panelHeight);
        this.add(containerView);

        int y = 0;

        items = todoList.getItems();

        for(TodoItem item : items){
            class EditingListener implements ActionListener{

                @Override
                public void actionPerformed(ActionEvent e) {
                    String text = textField1.getText();
                    todoListService.set(items.indexOf(item), new TodoItem(text));
                    editWindow.setVisible(false);
                    dataToView();
                }
            }
            Button edit = new Button("Edit");
            Button delete = new Button("Delete");
            edit.setSize(100, cellHeight);
            delete.setSize(100, cellHeight);
            edit.setLocation(this.getWidth() - edit.getWidth() - delete.getWidth() - 2 * paddingNormal, y);
            delete.setLocation(this.getWidth() - delete.getWidth() - paddingNormal, y);

            containerView.add(edit);
            containerView.add(delete);

            delete.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    int res = JOptionPane.showConfirmDialog(null,
                            "Are you sure deleting this item?","confirm",
                            JOptionPane.YES_NO_OPTION);
                    if(res == JOptionPane.YES_OPTION) {
                        todoListService.delete(item);
                        dataToView();
                    }else
                        return;
                }
            });

            EditingListener editingListener = new EditingListener();
            edit.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    editWindow = new JFrame();
                    editWindow.setSize(400,80);
                    editWindow.setLocation(550, 200);
                    editWindow.setLayout(new FlowLayout());

                    textField1 = new JTextField(30);
                    editWindow.add(textField1);
                    JButton button = new JButton("OK");
                    editWindow.add(button);
                    editWindow.setVisible(true);
                    button.addActionListener(editingListener);
                    textField1.addActionListener(editingListener);
                }
            });

            Label label = new Label();
            label.setText(item.getText());
            label.setLocation(paddingNormal, y);
            label.setSize(this.getWidth() - 2 * paddingNormal - edit.getX(), cellHeight);
            containerView.add(label);
            y += label.getHeight() + paddingNormal;
        }
        Button save = new Button("Save");
        save.setSize(100,cellHeight);
        save.setLocation(this.getWidth() - save.getWidth() - paddingNormal,
                y + paddingNormal);
        containerView.add(save);
        save.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                todoListService.save();
                JOptionPane.showMessageDialog(null,
                        "Todo List saved successfully.");
            }
        });
    }
}
